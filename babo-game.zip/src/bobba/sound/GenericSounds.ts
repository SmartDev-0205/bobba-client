export const SOUND_CREDITS = 'audio/cash_register.mp3';
export const SOUND_PIXELS = 'audio/pixels.mp3';
export const SOUND_CONSOLE_SENT = 'audio/sent_msg.mp3';
export const SOUND_CONSOLE_RECEIVE = 'audio/tururu.mp3';